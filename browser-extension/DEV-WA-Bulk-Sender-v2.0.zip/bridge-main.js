// Page (MAIN world) bridge — WhatsApp ke andar se seedha message bhejta hai (WPP / wa-js)
(() => {
  if (window.__devwaBridge) return;
  window.__devwaBridge = true;

  async function send({ phone, text, images }) {
    const r = await WPP.contact.queryWidExists(phone + '@c.us');
    if (!r) return { ok: false, notOnWA: true, reason: 'Number WhatsApp par nahi hai' };
    const chatId = r.wid;
    const opts = { createChat: true, waitForAck: true };
    if (images && images.length) {
      for (let i = 0; i < images.length; i++) {
        const o = { ...opts, type: 'image' };
        if (i === 0 && text) o.caption = text;
        await WPP.chat.sendFileMessage(chatId, images[i], o);
      }
    } else {
      await WPP.chat.sendTextMessage(chatId, text, opts);
    }
    return { ok: true };
  }

  window.addEventListener('message', async e => {
    if (e.source !== window) return;
    const d = e.data;
    if (!d || d.src !== 'devwa-req') return;
    let result;
    try {
      if (d.action === 'ready') {
        result = { ok: true, ready: !!(window.WPP && WPP.isFullReady) };
      } else if (d.action === 'send') {
        result = await send(d.payload);
      } else {
        result = { ok: false, error: 'unknown action' };
      }
    } catch (err) {
      result = { ok: false, error: String((err && err.message) || err) };
    }
    window.postMessage({ src: 'devwa-res', id: d.id, result }, '*');
  });
})();
