importScripts('common.js');

// Icon click -> Dashboard kholo (agar pehle se khula hai to wahi)
chrome.action.onClicked.addListener(async () => {
  const url = chrome.runtime.getURL('dashboard.html');
  const tabs = await chrome.tabs.query({ url });
  if (tabs.length) {
    await chrome.tabs.update(tabs[0].id, { active: true });
    await chrome.windows.update(tabs[0].windowId, { focused: true });
  } else {
    await chrome.tabs.create({ url });
  }
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'whoami') {
    sendResponse({ tabId: sender.tab ? sender.tab.id : null });
    return;
  }
  if (msg.type === 'start') {
    startOrResume().then(r => sendResponse(r)).catch(e => sendResponse({ ok: false, error: String(e) }));
    return true; // async
  }
});

const sleep = ms => new Promise(r => setTimeout(r, ms));

async function ping(tabId) {
  try { return await chrome.tabs.sendMessage(tabId, { type: 'devwa-run' }); }
  catch (e) { return null; }
}

// Extension reload/update ke baad WhatsApp tab me scripts dobara daalo — page refresh ke bina
async function inject(tabId) {
  const [{ result: hasWPP }] = await chrome.scripting.executeScript({
    target: { tabId }, world: 'MAIN', func: () => !!window.WPP
  });
  await chrome.scripting.executeScript({
    target: { tabId }, world: 'MAIN',
    files: hasWPP ? ['bridge-main.js'] : ['wppconnect-wa.js', 'bridge-main.js']
  });
  await chrome.scripting.executeScript({ target: { tabId }, files: ['common.js', 'content.js'] });
}

async function startOrResume() {
  const { job } = await chrome.storage.local.get('job');
  if (!job || !job.items || job.index >= job.items.length) return { ok: false, error: 'Koi pending item nahi' };

  job.status = 'running';
  job.stage = 'starting';
  job.pauseReason = '';

  const tabs = await chrome.tabs.query({ url: 'https://web.whatsapp.com/*' });
  if (tabs.length) {
    const tab = tabs[0];
    job.waTabId = tab.id;
    await chrome.storage.local.set({ job });
    await chrome.tabs.update(tab.id, { active: true });
    await chrome.windows.update(tab.windowId, { focused: true });

    let r = await ping(tab.id);
    if (!r) {
      try { await inject(tab.id); } catch (e) { /* ignore */ }
      await sleep(1500);
      r = await ping(tab.id);
    }
    if (!r || !r.ok) {
      const fresh = (await chrome.storage.local.get('job')).job;
      fresh.status = 'paused';
      fresh.pauseReason = 'WhatsApp tab se connect nahi hua — tab ek baar khud refresh karke Resume dabao';
      await chrome.storage.local.set({ job: fresh });
      return { ok: false, error: fresh.pauseReason };
    }
  } else {
    // WhatsApp khula hi nahi hai: ek baar normal kholo, load hote hi kaam shuru
    job.waTabId = null;
    await chrome.storage.local.set({ job });
    const tab = await chrome.tabs.create({ url: 'https://web.whatsapp.com/', active: true });
    const fresh = (await chrome.storage.local.get('job')).job;
    fresh.waTabId = tab.id;
    await chrome.storage.local.set({ job: fresh });
  }
  return { ok: true };
}
