# DEV WA Bulk Sender — Setup Guide

## Install (ek baar)
1. ZIP ko extract karo (jaise `D:\DEV-WA-Bulk`)
2. Chrome me `chrome://extensions` kholo
3. Upar right me **Developer mode** ON karo
4. **Load unpacked** dabao, phir extract kiya hua folder select karo
5. Puzzle 🧩 icon par jaake **DEV WA Bulk Sender** ko pin kar do

## Use kaise kare
1. Chrome me **web.whatsapp.com** kholo aur login rakho (QR scan)
2. Extension icon dabao. Dashboard khulega
3. **Contact list:** `Sample_Contacts.xlsx` jaisa Excel upload karo (Phone, Name, aur koi bhi column)
4. **Message:** `{Name}`, `{Firm}` jaise placeholders likho. Preview me check karo
5. **Images (optional):** ek ya zyada images select karo. Message pehli image ka caption banega
6. **Start** dabao. WhatsApp tab apne aap ek-ek chat kholke bhejega
7. Report table live update hogi. **Report Excel** se download karo

## Dhyan rakho
- **Pehli baar 2-3 apne numbers ki list se test karo.**
- Sending ke time WhatsApp tab me kuch click/type mat karo. Dusra kaam dusre tab ya window me karo.
- Laptop sleep me na jaye.
- Delay 25–60 sec aur daily limit ~150 rakho. Number ban ka risk kam rahega.
- Jo number WhatsApp par nahi hai, woh "Failed" me aayega. **Failed wale dobara** se retry kar sakte ho.
- Pause/Stop ke baad **Resume** wahi se shuru karega.
- WhatsApp apna design badle aur kuch kaam karna band ho jaye, to `content.js` ke selectors update karne padenge.
